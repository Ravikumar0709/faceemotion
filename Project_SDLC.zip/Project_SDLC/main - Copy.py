import streamlit as st
from process.file_management import extract_text_from_pdf, extract_text_from_txt
from process.run_process import run_process
from process.graph import create_sdlc_graph
import os

def main():
    # Path to the CSS file
    css_file_path = "static/styles.css"

    # Load the CSS file
    if os.path.exists(css_file_path):
        with open(css_file_path, "r") as f:
            st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
    else:
        st.error("CSS file not found.")

    # Sidebar for file upload
    with st.sidebar:
        st.markdown('''
        <div style="padding: 10px; background-color: #f0f2f6; border-radius: 5px;">
            <h2 style="color: #333; font-size: 20px; margin-bottom: 10px;">File Upload</h2>
            <p style="font-size: 14px; color: #555;">Upload your functional requirements document (PDF or TXT).</p>
            <div style="margin-top: 15px;">
                </div>
        </div>
        ''', unsafe_allow_html=True)
        uploaded_file = st.sidebar.file_uploader("Upload File", type=["pdf", "txt"], key="file_uploader_api")


        # Optional: Add more sidebar elements if needed
        st.sidebar.markdown("---")
        st.sidebar.markdown("**About**")
        st.sidebar.markdown("This application integrates Langgraph for SDLC process automation.")

    # Main content area
    st.markdown(
        """
        <div style="display: flex; flex-direction: column; align-items: center; margin-top: 10px;">
            <div class="header-container">
                <h1 style="font-size: 24px; font-weight: bold; text-align: center; margin-bottom: 5px;">SDLC Process with Langgraph Integration</h1>
                <p style="font-size: 14px; text-align: center; margin-bottom: 0;">Automate your Software Development Lifecycle using Language Models.</p>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    if uploaded_file:
        try:
            content = None
            if uploaded_file.type == "application/pdf":
                content = extract_text_from_pdf(uploaded_file)
            elif uploaded_file.type == "text/plain":
                content = extract_text_from_txt(uploaded_file)

            if not content or content.strip() == "":
                st.error("Failed to extract content from the uploaded file.")
                return

            st.subheader("Uploaded Functional Requirements:")
            st.markdown(f"<div style='border: 1px solid #ccc; padding: 10px; border-radius: 5px; white-space: pre-wrap;'>{content}</div>", unsafe_allow_html=True)

            # Create SDLC graph
            graph = create_sdlc_graph()

            # Run SDLC process
            run_process(content, graph)

        except Exception as e:
            st.error(f"Error processing the uploaded file: {e}")

if __name__ == "__main__":
    main()