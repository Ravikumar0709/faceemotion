# run_process.py

# process/run_process.py

import streamlit as st
import os
from process.graph import Graph, Node, create_sdlc_graph
from process.phases import generate_document
from process.diagram_generator import generate_sequence_diagram, generate_flowchart, generate_architecture_diagram, generate_process_flow_diagram, generate_er_diagram

def initialize_sdlc_state(graph: Graph, business_requirements_text: str):
    if 'sdlc_state' not in st.session_state:
        st.session_state['sdlc_state'] = {
            'current_phase_name': next(iter(graph.nodes)),
            'approval_pending': {},
            'document_generated': {},
            'phase_content': {next(iter(graph.nodes)): business_requirements_text},
        }

def run_process(business_requirements_text, graph: Graph):
    """Run the SDLC process."""
    initialize_sdlc_state(graph, business_requirements_text)
    state = st.session_state['sdlc_state']
    current_phase: Node = graph.nodes[state['current_phase_name']]

    st.write(f"Processing Phase: {current_phase.name} (Status: {current_phase.status})")

    if current_phase.name not in state['phase_content']:
        state['phase_content'][current_phase.name] = state['phase_content'].get(graph.nodes[current_phase.prev_node.name].name) if current_phase.prev_node else business_requirements_text

    phase_input = state['phase_content'][current_phase.name]

    if current_phase.status == "Pending" and not state['document_generated'].get(current_phase.name, False):
        st.write(f"DEBUG: Calling tool_function for phase: {current_phase.name}")
        st.write(f"DEBUG: tool_function object: {current_phase.tool_function}")
        st.write(f"DEBUG: phase_input: {phase_input[:100]}...") # Print a snippet of the input
        content = current_phase.tool_function(phase_input)
        if content:
            st.write(f"{current_phase.name} Generated Document:")
            st.write(content)
            state['document_generated'][current_phase.name] = True
            state['phase_content'][current_phase.name] = content
            current_phase.output = content
        else:
            st.warning(f"No content generated for {current_phase.name}. Please check the input or try again.")
            return

    if current_phase.name not in state['approval_pending']:
        state['approval_pending'][current_phase.name] = False

    col1, col2 = st.columns(2)
    with col1:
        approve_button = st.button(f"Approve {current_phase.name}", key=f"approve_{current_phase.name}")
    with col2:
        disapprove_button = st.button(f"Disapprove {current_phase.name}", key=f"disapprove_{current_phase.name}")

    if approve_button:
        if current_phase.name == "User Stories":
            # Example process flow diagram for User Stories
            processes = {"Start": "Receive Requirements", "Generate": "Generate User Stories", "Review": "Review Stories", "End": "User Stories Approved"}
            flow = [("Start", "Generate", ""), ("Generate", "Review", ""), ("Review", "End", "Approved"), ("Review", "Generate", "Rejected")]
            diagram_filename = generate_process_flow_diagram(processes, flow, "user_stories_flow")
            with open(os.path.join("diagrams", diagram_filename), "rb") as f:
                st.session_state['diagram_content'] = f.read()
                st.session_state['generate_diagram'] = True
        elif current_phase.name == "Design":
            # Example architecture diagram for Design
            components = {"Client": {"type": "User Interface"}, "API Gateway": {"type": "Entry Point"}, "Business Logic": {"type": "Application"}, "Database": {"type": "Data Store"}}
            connections = [("Client", "API Gateway", "Requests"), ("API Gateway", "Business Logic", "Processes"), ("Business Logic", "Database", "Stores/Retrieves")]
            diagram_filename = generate_architecture_diagram(components, connections, "design_architecture")
            with open(os.path.join("diagrams", diagram_filename), "rb") as f:
                st.session_state['diagram_content'] = f.read()
                st.session_state['generate_diagram'] = True
        elif current_phase.name == "Code Generation":
            # Example sequence diagram for Code Generation (simplified)
            interactions = [("Developer", "Code Generator", "Input Design"), ("Code Generator", "Developer", "Generated Code")]
            diagram_filename = generate_sequence_diagram(interactions, "code_generation_sequence")
            with open(os.path.join("diagrams", diagram_filename), "rb") as f:
                st.session_state['diagram_content'] = f.read()
                st.session_state['generate_diagram'] = True
        elif current_phase.name == "Test Case Generation":
            # Example flowchart for a test case scenario
            steps = {"Start": ("Receive Input", "Check Valid"), "Check Valid": ("Validate Input", "Process Data/Invalid"), "Process Data/Invalid": ("Process Data (if valid) / Handle Error (if invalid)", "End")}
            diagram_filename = generate_flowchart(steps, "test_case_flow")
            with open(os.path.join("diagrams", diagram_filename), "rb") as f:
                st.session_state['diagram_content'] = f.read()
                st.session_state['generate_diagram'] = True
        elif current_phase.name == "QA":
            # Example process flow for QA Review
            processes = {"Submit": "Code/Tests Submitted", "Review": "QA Review", "Approve/Reject": "Approve or Reject", "Rework": "Send for Rework"}
            flow = [("Submit", "Review", ""), ("Review", "Approve/Reject", ""), ("Approve/Reject", "Rework", "Reject"), ("Approve/Reject", "Next Phase", "Approve")]
            diagram_filename = generate_process_flow_diagram(processes, flow, "qa_review_flow")
            with open(os.path.join("diagrams", diagram_filename), "rb") as f:
                st.session_state['diagram_content'] = f.read()
                st.session_state['generate_diagram'] = True

        current_phase.approve()
        state['approval_pending'][current_phase.name] = True
        if current_phase.next_nodes:
            state['current_phase_name'] = current_phase.next_nodes[0].name
        else:
            state['current_phase_name'] = None
        st.rerun()

    elif disapprove_button:
        current_phase.disapprove()
        state['approval_pending'][current_phase.name] = True
        if current_phase.prev_node:
            state['current_phase_name'] = current_phase.prev_node.name
            st.warning(f"Returning to {current_phase.prev_node.name} phase for rework.")
            st.rerun()
        else:
            st.error("No previous phase to return to.")
            return

    if state['current_phase_name'] is not None:
        current_phase = graph.nodes[state['current_phase_name']]
        if current_phase.status == "Approved" and current_phase.next_nodes and not state['approval_pending'].get(current_phase.next_nodes[0].name, False):
            state['current_phase_name'] = current_phase.next_nodes[0].name
            st.rerun()
        elif current_phase.status == "Approved" and not current_phase.next_nodes:
            st.write("SDLC process completed successfully!")
            state['current_phase_name'] = None

    if st.session_state.get('generate_diagram', False) and st.session_state.get('diagram_content'):
        st.subheader("Generated Diagram")
        diagram_content = st.session_state['diagram_content']
        diagram_filename = f"{state['current_phase_name'].replace(' ', '_').lower()}_diagram.png"
        diagram_path = os.path.join("diagrams", diagram_filename)
        st.image(diagram_content, caption=f"{state['current_phase_name']} Diagram")
        # Optionally clear the state after displaying
        st.session_state['generate_diagram'] = False
        st.session_state['diagram_content'] = None