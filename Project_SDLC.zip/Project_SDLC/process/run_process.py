# process/run_process.py

import streamlit as st
from process.graph import Graph, Node, create_sdlc_graph
from process.phases import generate_document
from process.diagram_generator import generate_diagram

def initialize_sdlc_state(graph: Graph, business_requirements_text: str):
    if 'sdlc_state' not in st.session_state:
        st.session_state['sdlc_state'] = {
            'current_phase_name': next(iter(graph.nodes)),
            'approval_pending': {},
            'document_generated': {},
            'phase_content': {next(iter(graph.nodes)): business_requirements_text},
        }

def run_process(business_requirements_text, graph: Graph):
    """Run the SDLC process."""
    initialize_sdlc_state(graph, business_requirements_text)
    state = st.session_state['sdlc_state']
    current_phase: Node = graph.nodes[state['current_phase_name']]

    st.write(f"Processing Phase: {current_phase.name} (Status: {current_phase.status})")

    if current_phase.name not in state['phase_content']:
        state['phase_content'][current_phase.name] = state['phase_content'].get(graph.nodes[current_phase.prev_node.name].name) if current_phase.prev_node else business_requirements_text

    phase_input = state['phase_content'][current_phase.name]

    if current_phase.status == "Pending" and not state['document_generated'].get(current_phase.name, False):
        st.write(f"DEBUG: Calling tool_function for phase: {current_phase.name}")
        st.write(f"DEBUG: tool_function object: {current_phase.tool_function}")
        st.write(f"DEBUG: phase_input: {phase_input[:100]}...") # Print a snippet of the input
        content = current_phase.tool_function(phase_input)
        if content:
            st.write(f"{current_phase.name} Generated Document:")
            st.write(content)
            state['document_generated'][current_phase.name] = True
            state['phase_content'][current_phase.name] = content
            current_phase.output = content
        else:
            st.warning(f"No content generated for {current_phase.name}. Please check the input or try again.")
            return

    if current_phase.name not in state['approval_pending']:
        state['approval_pending'][current_phase.name] = False

    col1, col2 = st.columns(2)
    with col1:
        approve_button = st.button(f"Approve {current_phase.name}", key=f"approve_{current_phase.name}")
    with col2:
        disapprove_button = st.button(f"Disapprove {current_phase.name}", key=f"disapprove_{current_phase.name}")

    if approve_button:
        current_phase.approve()
        state['approval_pending'][current_phase.name] = True
        if current_phase.next_nodes:
            state['current_phase_name'] = current_phase.next_nodes[0].name
        else:
            state['current_phase_name'] = None
        st.rerun()

    elif disapprove_button:
        current_phase.disapprove()
        state['approval_pending'][current_phase.name] = True
        if current_phase.prev_node:
            state['current_phase_name'] = current_phase.prev_node.name
            st.warning(f"Returning to {current_phase.prev_node.name} phase for rework.")
            st.rerun()
        else:
            st.error("No previous phase to return to.")
        return

    if state['current_phase_name'] is not None:
        current_phase = graph.nodes[state['current_phase_name']]
        if current_phase.status == "Approved" and current_phase.next_nodes and not state['approval_pending'].get(current_phase.next_nodes[0].name, False):
            state['current_phase_name'] = current_phase.next_nodes[0].name
            st.rerun()
        elif current_phase.status == "Approved" and not current_phase.next_nodes:
            st.write("SDLC process completed successfully!")
            state['current_phase_name'] = None

    st.write("DEBUG: Checking for diagram generation...")
    st.write(f"DEBUG: st.session_state.get('generate_diagram', False): {st.session_state.get('generate_diagram', False)}")
    st.write(f"DEBUG: st.session_state.get('diagram_content') exists: {st.session_state.get('diagram_content') is not None}")
    if st.session_state.get('diagram_content'):
        st.write(f"DEBUG: First 100 chars of diagram_content: {st.session_state['diagram_content'][:100]}...")

    if st.session_state.get('generate_diagram', False) and st.session_state.get('diagram_content'):
        st.subheader("Generated Diagrams")
        diagram_content = st.session_state['diagram_content']
        technical_design_diagram = generate_diagram(diagram_content, diagram_type="technical_design")
        if technical_design_diagram:
            st.image(technical_design_diagram, caption="Technical Design Diagram", use_column_width=True)
        else:
            st.warning("Could not generate technical design diagram.")

        erd_diagram = generate_diagram(diagram_content, diagram_type="erd")
        if erd_diagram:
            st.image(erd_diagram, caption="ER Diagram", use_column_width=True)
        else:
            st.warning("Could not generate ER diagram.")

        st.session_state['generate_diagram'] = False