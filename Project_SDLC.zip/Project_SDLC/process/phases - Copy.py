import os
import pdfkit
from fpdf import FPDF
import streamlit as st
from langchain_groq import ChatGroq
from config.config import LLM_MODEL
from dotenv import load_dotenv
import os
import html5lib
# Load environment variables
load_dotenv()
import html5lib

CHATGROQ_API_KEY = os.getenv("GROQ_API_KEY")
os.environ["GROQ_API_KEY"] = CHATGROQ_API_KEY
os.environ["GOOGLE_API_KEY"] = os.getenv("GOOGLE_API_KEY")

# Ensure /doc directory exists
if not os.path.exists("doc"):
    os.makedirs("doc")


import html  # Add this import


def clean_content(content):
    # Remove unwanted symbols like '####', '**', and '-'
    content = content.replace('####', '').replace('**', '').replace('-', '')
    return content

def generate_document(phase_name, content, sections=None):
    try:
        # Clean the content to remove unwanted symbols
        content = clean_content(content)

        # Generate HTML for the document with embedded CSS for styling
        html_content = f"""
        <html>
        <head>
            <meta charset='UTF-8'>
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    font-size: 25px;  /* Normal font size for body text */
                    line-height: 1.6;
                }}
                h1 {{
                    font-size: 48px;  /* Larger font size for main headers */
                    text-align: center;
                    font-weight: normal;
                }}
                h2 {{
                    font-size: 40px;  /* Slightly smaller for subheaders */
                    font-weight: normal;
                }}
                h3 {{
                    font-size: 35px;  /* Even smaller for smaller subheaders */
                    font-weight: normal;
                }}
                p {{
                    margin: 15px 0;
                    font-weight: normal;
                }}
                .subheader {{
                    font-size: 25px;  /* Normal size for custom subheaders */
                    color: #333;
                    margin: 20px 0;
                    font-weight: normal;
                }}
            </style>
        </head>
        <body>
            <h1>{phase_name} Document</h1>
        """

        # Add Table of Contents if sections are provided
        if sections:
            html_content += "<h2>Table of Contents</h2><ul>"
            for section in sections:
                html_content += f"<li>{section}</li>"
            html_content += "</ul>"

        # Process content to replace Markdown-like formatting with HTML
        lines = content.split('\n')
        
        for line in lines:
            # Detect subheaders like "User Story 1: User Sign-Up"
            if line.strip().startswith("User Story") or line.strip().startswith("Scenario") or ":" in line:
                line = f'<p class="subheader">{line.strip()}</p>'
            # Process headers
            elif line.startswith('### '):  # Markdown-style H3 header
                line = f"<h3>{line[4:].strip()}</h3>"
            elif line.startswith('## '):  # Markdown-style H2 header
                line = f"<h2>{line[3:].strip()}</h2>"
            elif line.startswith('# '):  # Markdown-style H1 header
                line = f"<h1>{line[2:].strip()}</h1>"
            else:
                # Regular paragraph without bold formatting
                line = f"<p>{line.strip()}</p>"

            # Add the processed line to the document
            html_content += line

        html_content += "</body></html>"

        # Save HTML content to file
        output_path_html = f"doc/{phase_name}_Document.html"
        with open(output_path_html, "w", encoding='utf-8') as file:
            file.write(html_content)

        # Convert HTML to PDF using pdfkit
        output_path_pdf = f"doc/{phase_name}_Document.pdf"
        pdfkit.from_file(output_path_html, output_path_pdf)

        # Provide success feedback to user
        st.success(f"{phase_name} document generated successfully.")

        # Sidebar download buttons with customized color
        st.sidebar.markdown(
            f"""
            <style>
                .download-btn {{
                    background-color: #4CAF50; /* Green color */
                    color: white;
                    padding: 10px 20px;
                    border-radius: 5px;
                    text-align: center;
                    cursor: pointer;
                    font-size: 20px; 
                    font-weight: normal;
                }}
                .download-btn:hover {{
                    background-color: #45a049;
                }}
            </style>
            """, unsafe_allow_html=True)

        # Sidebar download buttons
        st.sidebar.download_button(
            label=f"Download {phase_name} Document (PDF)", 
            data=open(output_path_pdf, "rb").read(), 
            file_name=f"{phase_name}_Document.pdf",
            mime="application/pdf",
            key=f"{phase_name}_download_btn_pdf"
        )
        st.sidebar.download_button(
            label=f"Download {phase_name} Document (HTML)", 
            data=open(output_path_html, "r", encoding='utf-8').read(), 
            file_name=f"{phase_name}_Document.html",
            mime="text/html",
            key=f"{phase_name}_download_btn_html"
        )
    except Exception as e:
        st.error(f"Error generating document: {e}")



# Cache to store previously generated user stories
user_stories_cache = {}

def generate_user_stories(input_text):
    """Generate user stories from business requirements. Ensures deterministic output."""

    # Check if we have already generated user stories for this input
    if input_text in user_stories_cache:
        return user_stories_cache[input_text]

    # Modify the prompt to guide the model in creating actionable and structured user stories
    prompt = f"""
    Generate detailed user stories from the following business requirements:
    {input_text}

    Each user story should be structured as:
    As a [user role], I want to [action] so that I can [goal/benefit]. 
    Break down the business requirements into specific user stories, each representing a feature or function of the system.
    Make sure to specify the intended user role (e.g., customer, admin, manager) and the specific goal or benefit the user will get from performing the action.
    Each story should be clear and concise, and avoid ambiguity.
    Include acceptance criteria for each user story if applicable (e.g., conditions under which the story is considered "done").
    Ensure that the user stories align with the business objectives described in the input.
    """

    # Use LLM (e.g., ChatGroq or GPT model) to generate the user stories with deterministic output
    llm = ChatGroq(model=LLM_MODEL)
    result = llm.invoke(prompt, temperature=0)  # Set temperature to 0 for deterministic output

    # Extract the content from the LLM response
    content = result.text().strip()

    if content:
        # Save the generated content to the cache
        user_stories_cache[input_text] = content

        # Split the content into sections
        sections = []
        for line in content.split('\n'):
            if line.startswith('As a '):
                sections.append(line)

        # Generate document with sections
        generate_document("User Stories", content, sections)

        return content

    return None



# Additional functions can be updated similarly for generating design, code, test cases, etc., with proper formatting.
design_cache = {}
def generate_design(input_text):
    """Generate a design document from user stories and key design components with deterministic output."""

    # Check if we have already generated the design document for this input
    if input_text in design_cache:
        return design_cache[input_text]

    # Define the prompt for generating the technical design document
    prompt = f"""
    Generate a detailed technical design document based on the following user stories:
    {input_text}

    The document should include the following sections with detailed content:

    1. **Introduction**: Provide an overview of the system, its purpose, scope, and the problem it solves. Include any key business or technical objectives the system aims to achieve.

    2. **System Architecture**: Describe the high-level architecture of the system, including key components and their interactions. If applicable, include technologies used (e.g., Java, Node.js for the backend, React for the frontend) and high-level architecture diagrams (e.g., microservices, monolithic, serverless, cloud-based).

    3. **Functional Requirements**: Outline the system’s functional requirements. These should detail the actions the system must be able to perform. Include user stories, use cases, or features that the system should support, such as user registration, data processing, and reporting.

    4. **Non-Functional Requirements**: List the system’s non-functional requirements such as scalability, performance, availability, maintainability, and security. Specify any measurable quality attributes, including latency, response time, or throughput expectations. Discuss system availability (e.g., 99.9% uptime) and failure recovery.

    5. **User Interface**: Describe the design and structure of the user interface, including high-level wireframes or mockups if applicable. Include user flow, key interactions, and accessibility considerations. Explain how users will interact with the system and what devices/browsers it supports.

    6. **Software Components**: Provide detailed information about the individual software components/modules used in the system. This includes:
       - Backend components: Mention the technologies like Java (Spring Boot), Node.js (Express), or Python (Django/Flask).
       - Frontend components: Explain the frontend framework, such as React, Angular, or Vue.js.
       - APIs and external services: Discuss any APIs, such as RESTful APIs, GraphQL, or SOAP services, and third-party integrations (e.g., payment gateways, analytics).
       - Other tools: Include technologies such as Docker for containerization, Kubernetes for orchestration, Kafka for messaging, CI/CD tools, etc.

    7. **Database Schema**: Include the database schema design with details on tables, fields, relationships, and any database technologies (e.g., MySQL, PostgreSQL, MongoDB).
         - Provide list of tables, columns, data type, primary key, foreign key relationship,indexing strategies. If applicable, include ER diagrams to visualize the data model.

    8. **Security**: Explain the security measures and protocols employed in the system, including authentication and authorization mechanisms (e.g., OAuth, JWT, LDAP). Discuss encryption, secure data storage, network security, and how the system addresses threats such as SQL injection, cross-site scripting (XSS), or cross-site request forgery (CSRF).

    9. **Conclusion**: Summarize the key points of the design document. Highlight any important considerations and possible future improvements or extensions. Include a discussion of known risks and how they are mitigated, as well as any technical debts or dependencies that could affect future development.

    Please ensure each section is well-detailed and clear. If necessary, include relevant diagrams (e.g., system architecture, database schema, user flow) to aid understanding.
    """

    # Use LLM (e.g., ChatGroq or GPT model) to generate the document based on the prompt
    llm = ChatGroq(model=LLM_MODEL)
    result = llm.invoke(prompt, temperature=0)  # Set temperature to 0 for deterministic output

    # Extract the content from the LLM response
    content = result.text().strip()

    if content:
        # Save the generated content to the cache to ensure it is reused
        design_cache[input_text] = content

        # Assuming a function 'generate_document' to output or save the document
        generate_document("Technical Design", content)
        return content

    return None




code_cache = {}
def generate_code(input_text):
    """Generate code from design document."""
    prompt = f"""
    You are a software developer tasked with generating code based on a design document. 
    The design document below outlines the requirements, logic, and expected structure of the code.

    Design Document:
    {input_text}

    Please generate the corresponding code based on the design document. Ensure the following:
    - The code follows best practices.
    - Use appropriate variable and function names.
    - Create database schema and tables along with constraints in sql
    - create source code like java, stored procedure or any other code for front end and back end as appropriate 
    - create interfaces code as required 
    - Create integration code as required 
    - If applicable, include comments explaining the code.
    - Ensure that the code is executable and functional based on the described design.
    """

    llm = ChatGroq(model=LLM_MODEL)
    result = llm.invoke(prompt, temperature=0)  # Set temperature to 0 for deterministic output
    content = result.text().strip()
    
    if content:
        # Save the generated content to the cache to ensure it is reused
        code_cache[input_text] = content
        generate_document("Code Generation", content)
        return content
    return None

test_cache = {}
def generate_test_cases(input_text):
    """Generate test cases from code/design."""
    prompt = f"""
    You are a software developer tasked with generating test cases based on the following code or design document.
    The code/design document below outlines the functionality or logic that needs to be tested.

    Code/Design Document:
    {input_text}

    Please generate a set of test cases to thoroughly test this code/design. The test cases should:
    - Cover a variety of scenarios, including typical, edge, and corner cases.
    - Ensure both positive and negative test cases are included (i.e., valid inputs and invalid inputs).
    - Be structured in a way that aligns with common testing frameworks (e.g., unit tests, integration tests).
    - If applicable, use the appropriate testing framework for the language or environment of the code (e.g., pytest for Python, JUnit for Java).
    - For each test case, provide the expected result and a brief description of what is being tested.

    The test cases should be written clearly and concisely.
    """
    
    llm = ChatGroq(model=LLM_MODEL)
    result = llm.invoke(prompt, temperature=0)  # Set temperature to 0 for deterministic output
    content = result.text().strip()

    if content:
        # Save the generated content to the cache to ensure it is reused
        test_cache[input_text] = content
        generate_document("Test Case Generation", content)
        return content
    return None

test_script_cache = {}
def generate_test_script(input_text):
    """Generate test scripts from Test Cases/design, ensuring comprehensive coverage and automation readiness."""
    prompt = f"""
    Generate test scripts based on the following test cases/design/code:\n{input_text}
    
    Please consider the following while generating the test scripts:
    - Focus on unit testing and ensure thorough coverage of all possible scenarios, including edge cases and error handling.
    - Ensure that the test scripts are compatible with the pytest automation framework and include necessary assertions.
    - Include expected results for each test case along with relevant validation steps.
    - Provide suggestions for test data that covers a wide range of inputs, including both valid and invalid data.
    - Make sure to handle error conditions gracefully and log failure details for debugging purposes.
    - If the test cases have dependencies, order them logically, making sure each test is independent where possible.
    
    Use the above instructions to generate clean, concise, and automated-ready test scripts.
    """
    
    llm = ChatGroq(model=LLM_MODEL)
    result = llm.invoke(prompt, temperature=0)  # Set temperature to 0 for deterministic output
    content = result.text().strip()
    
    if content:
        # Save the generated content to the cache to ensure it is reused
        test_script_cache[input_text] = content
        generate_document("Test Script Generation", content)
        return content
    
    return None

qa_review_cache = {}
def qa_review(input_text):
    """Simulate QA review with detailed focus on key quality aspects."""
    prompt = f"""
    Review the following test cases/design/code for quality assurance:\n{input_text}
    
    Please consider the following while reviewing the test cases:
    - **Test Coverage**: Ensure all possible scenarios are covered, including edge cases, boundary conditions, and invalid inputs.
    - **Clarity and Readability**: Check that the test cases are clearly written, easy to understand, and well-documented. Complex logic should be explained with comments.
    - **Test Independence**: Verify that each test case is independent and does not have unnecessary dependencies on other tests.
    - **Correctness**: Ensure that the test cases are logically correct, the expected results are accurate, and assertions are appropriately used.
    - **Error Handling and Logging**: Confirm that proper error handling is implemented and that adequate logging exists for test failures or edge cases.
    - **Automation Compatibility**: Ensure that the test cases can be easily automated, compatible with common test frameworks (e.g., pytest, JUnit), and can be reused.
    - **Performance Considerations**: If applicable, ensure there are test cases for performance, load, and scalability.
    - **Code Style and Best Practices**: Check for adherence to coding standards and best practices. Ensure that the test cases are maintainable and not overly complex.
    
    Please provide feedback or suggestions for improvements based on these points.
    """
    
    llm = ChatGroq(model=LLM_MODEL)
    result = llm.invoke(prompt, temperature=0)  # Set temperature to 0 for deterministic output
    content = result.text().strip()
    
    if content:
        # Save the generated content to the cache to ensure it is reused
        qa_review_cache[input_text] = content
        generate_document("QA Review", content)
        return content
    
    return None

def deploy_code(input_text):
    """Simulate deployment after QA approval with step-by-step instructions."""
    
    prompt = f"""
    Deploy the following code to production, following these steps and instructions:

    1. **Code Verification**: 
       - Ensure the code has passed all unit tests, integration tests, and QA review. Confirm that no critical bugs or issues are pending.

    2. **Environment Check**: 
       - Verify that the target production environment is set up correctly (e.g., correct servers, network configurations, required environment variables).
       - Ensure that all dependencies are properly installed and configured.

    3. **Staging Deployment**:
       - Deploy the code to a staging environment first. This allows for final testing in an environment that mirrors production.
       - Run end-to-end tests in the staging environment to confirm that the code functions as expected.

    4. **Backup and Rollback Plan**:
       - Take a backup of the current production environment (code, data, configurations) in case a rollback is necessary.
       - Ensure that a rollback plan is in place and can be executed quickly if needed.

    5. **Production Deployment**:
       - Once the staging deployment is verified, deploy the code to the production environment.
       - Ensure that deployment is executed without causing downtime or affecting users.

    6. **Post-Deployment Validation**:
       - After deployment, validate that the application is running correctly in production. Check that all critical functionality is intact and there are no errors.
       - Perform smoke tests to confirm the deployment was successful.

    7. **Monitoring and Alerts**:
       - Set up or confirm monitoring tools to track system health after deployment.
       - Set up alerts to notify the team if any issues arise post-deployment, such as errors or performance problems.

    Please simulate the deployment process and confirm each step as it is completed successfully.
    """
    
    # Here you would integrate the actual deployment process or a service like ChatGroq for this step.
    # For now, we will simulate the success message.
    return "Deployment successful"  # Simulate successful deployment