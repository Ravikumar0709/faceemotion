# graph.py
# graph.py
from process.phases import generate_user_stories, generate_design, generate_code, generate_test_cases, generate_test_script, qa_review, deploy_code

class Node:
    def __init__(self, name, tool_function, tool_condition_function):
        self.name = name
        self.tool_function = tool_function
        self.tool_condition_function = tool_condition_function
        self.status = "Pending"
        self.next_nodes = []
        self.prev_node = None
        self.output = None # To store the output of the tool function

    def set_next_node(self, next_node):
        self.next_nodes.append(next_node)
        next_node.prev_node = self

    def approve(self):
        self.status = "Approved"

    def disapprove(self):
        self.status = "Disapproved"

    def is_ready(self):
        return self.tool_condition_function(self.name)


class Edge:
    def __init__(self, from_node, to_node):
        self.from_node = from_node
        self.to_node = to_node


class Graph:
    def __init__(self):
        self.nodes = {}
        self.edges = []

    def add_node(self, node):
        self.nodes[node.name] = node

    def add_edge(self, from_node, to_node):
        edge = Edge(from_node, to_node)
        self.edges.append(edge)

    def traverse(self, start_node, phase_content):
        current_node = start_node
        while current_node:
            if current_node.status == "Pending" and current_node.is_ready():
                content = current_node.tool_function(phase_content)
                if content:
                    current_node.output = content # Store the output
                    phase_content = content
                    current_node.status = "Completed"
                else:
                    break

            if current_node.status == "Approved" and current_node.next_nodes:
                next_node = current_node.next_nodes[0]
                current_node = next_node
            else:
                break
        return phase_content


def create_sdlc_graph():
    graph = Graph()

    # Define tool functions
    tools = {
        "User Stories": generate_user_stories,
        "Design": generate_design,
        "Code Generation": generate_code,
        "Test Case Generation": generate_test_cases,
        "Test Script Generation": generate_test_script,
        "QA": qa_review,
        "Deployment": deploy_code
    }

    # Create nodes for each SDLC phase
    nodes = {}
    for phase_name, tool_function in tools.items():
        node = Node(phase_name, tool_function, lambda phase_name: True)  # Simple condition for now
        nodes[phase_name] = node
        graph.add_node(node)

    # Link phases in SDLC order
    nodes["User Stories"].set_next_node(nodes["Design"])
    nodes["Design"].set_next_node(nodes["Code Generation"])
    nodes["Code Generation"].set_next_node(nodes["Test Case Generation"])
    nodes["Test Case Generation"].set_next_node(nodes["Test Script Generation"])
    nodes["Test Script Generation"].set_next_node(nodes["QA"])
    nodes["QA"].set_next_node(nodes["Deployment"])

    return graph