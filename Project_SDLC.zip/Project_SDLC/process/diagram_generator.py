# process/diagram_generator.py
import streamlit as st
from langchain_groq import ChatGroq
from config.config import LLM_MODEL
import base64
import requests

def generate_diagram(design_document: str, diagram_type: str = "technical_design"):
    """Generates a diagram (PlantUML) based on the design document."""
    if diagram_type == "technical_design":
        prompt = f"""
        You are a PlantUML expert. Based on the following technical design document:
        ```
        {design_document}
        ```
        Generate ONLY the PlantUML code to represent the system architecture. Focus on the main components and their interactions.
        Use appropriate stereotypes (e.g., <<database>>, <<web server>>, <<application>>) where relevant.
        The PlantUML code MUST be enclosed within ```plantuml and ``` delimiters. Do not include any other explanations or text.
        """
    elif diagram_type == "erd":
        prompt = f"""
        You are a PlantUML expert. Based on the 'Database Schema' section of the following technical design document:
        ```
        {design_document}
        ```
        Generate ONLY the PlantUML code for an Entity-Relationship Diagram (ERD) representing the database schema.
        Include entities (tables) with their key attributes (at least primary keys and important foreign keys), and clearly show the relationships between them (e.g., one-to-many, many-to-many).
        The PlantUML code MUST be enclosed within ```plantuml and ``` delimiters. Do not include any other explanations or text.
        """
    else:
        return None

    llm = ChatGroq(model=LLM_MODEL)
    result = llm.invoke(prompt, temperature=0.2)

    plantuml_code = ""
    if result and hasattr(result, 'content') and isinstance(result.content, str):
        if "```plantuml" in result.content and "```" in result.content:
            start = result.content.find("```plantuml") + len("```plantuml")
            end = result.content.find("```", start)
            if end != -1:
                plantuml_code = result.content[start:end].strip()
            else:
                st.warning("DEBUG: Could not find closing ``` delimiter for PlantUML code.")
                st.code(result.content)
                return None
        elif "```" in result.content:
            parts = result.content.split("```")
            if len(parts) > 1:
                plantuml_code = parts[1].strip()
                st.warning("DEBUG: Extracted PlantUML from generic code block (no 'plantuml' keyword).")
                st.code(result.content)
            else:
                st.warning("DEBUG: Could not find PlantUML code delimiters.")
                st.code(result.content)
                return None
        else:
            st.warning("DEBUG: No code delimiters found in LLM response.")
            st.code(result.content)
            return None
    else:
        st.error(f"Error: Unexpected response structure from LLM for diagram generation. Result: {result}")
        return None

    st.write(f"DEBUG ({diagram_type}): Generated PlantUML Code:\n{plantuml_code}")

    try:
        image_bytes = get_plantuml_image(plantuml_code)
        return image_bytes
    except Exception as e:
        st.error(f"Error generating {diagram_type} diagram: {e}")
        st.code(plantuml_code)
        return None

def get_plantuml_image(plantuml_code: str) -> bytes:
    """Generates an image from PlantUML code using an online server (Base64 encoding with ~1 fix)."""
    image_format = "png"
    plantuml_bytes = plantuml_code.encode('utf-8')
    base64_bytes = base64.b64encode(plantuml_bytes).decode('ascii')
    image_url = f"http://www.plantuml.com/plantuml/{image_format}/{base64_bytes}~1"  # Added ~1
    st.write(f"DEBUG: PlantUML Image URL (with ~1): {image_url}") # Debug URL
    try:
        response = requests.get(image_url, timeout=10)
        response.raise_for_status()
        st.write(f"DEBUG: Successfully fetched PlantUML image from (with ~1): {image_url}")
        return response.content
    except requests.exceptions.RequestException as e:
        st.error(f"Error fetching PlantUML image (with ~1): {e}")
        raise Exception(f"Error fetching PlantUML image (with ~1): {e}")