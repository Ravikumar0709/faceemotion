# diagram_generator.py
import os
from graphviz import Digraph

def save_diagram(dot, filename):
    filepath = os.path.join("diagrams", filename)
    dot.render(filepath, format='png', cleanup=True)
    return filename + ".png"

def generate_sequence_diagram(interactions, filename="sequence_diagram"):
    dot = Digraph(comment='Sequence Diagram')
    # Add nodes (participants)
    participants = set()
    for sender, receiver, _ in interactions:
        participants.add(sender)
        participants.add(receiver)
    for participant in participants:
        dot.node(participant)

    # Add edges (messages)
    for sender, receiver, message in interactions:
        dot.edge(sender, receiver, message)

    return save_diagram(dot, filename)

def generate_flowchart(steps, filename="flowchart"):
    dot = Digraph(comment='Flowchart')
    for step_id, (description, next_step) in steps.items():
        dot.node(step_id, description, shape='box')
        if next_step:
            dot.edge(step_id, next_step)
    return save_diagram(dot, filename)

def generate_architecture_diagram(components, connections, filename="architecture_diagram"):
    dot = Digraph(comment='Technical Architecture')
    for component, details in components.items():
        dot.node(component, label=f"{component}\n{details.get('type', '')}", shape='component')
    for source, target, description in connections:
        dot.edge(source, target, label=description)
    return save_diagram(dot, filename)

def generate_process_flow_diagram(processes, flow, filename="process_flow_diagram"):
    dot = Digraph(comment='Process Flow')
    for process_id, description in processes.items():
        dot.node(process_id, description, shape='ellipse')
    for source, target, label in flow:
        dot.edge(source, target, label=label)
    return save_diagram(dot, filename)

def generate_er_diagram(entities, relationships, filename="er_diagram"):
    dot = Digraph(comment='ER Diagram')
    for entity, attributes in entities.items():
        label = f"{entity}\n---\n" + "\n".join(attributes)
        dot.node(entity, label=label, shape='rectangle')
    for entity1, entity2, relation, cardinality1, cardinality2 in relationships:
        label = f"{relation}\n({cardinality1}-{cardinality2})"
        dot.edge(entity1, entity2, label=label, arrowhead='vee', arrowtail='vee')
    return save_diagram(dot, filename)