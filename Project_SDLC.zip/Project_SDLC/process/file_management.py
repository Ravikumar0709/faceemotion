# file_management.py

# process/file_management.py
from PyPDF2 import PdfReader

def extract_text_from_pdf(uploaded_file):
    reader = PdfReader(uploaded_file)
    text = ""
    for page in reader.pages:
        text += page.extract_text()
    return text

def extract_text_from_txt(uploaded_file):
    return uploaded_file.read().decode("utf-8")
