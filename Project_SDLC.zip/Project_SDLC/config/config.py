import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

CHATGROQ_API_KEY = os.getenv("GROQ_API_KEY")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
LLM_MODEL = "qwen-2.5-32b"
