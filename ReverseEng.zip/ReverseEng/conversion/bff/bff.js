const express = require('express');
const { graphqlHTTP } = require('express-graphql');
const { buildSchema } = require('graphql');
const fetch = require('node-fetch');

const app = express();
const port = 4000;

// GraphQL schema
const schema = buildSchema(`
  type InventoryItem {
    itemId: Int
    name: String
    quantity: Int
    price: Float
  }

  type Query {
    inventory: [InventoryItem]
  }
`);

// Resolver function to fetch inventory data from the Inventory Service
const root = {
  inventory: async () => {
    const response = await fetch('http://localhost:8080/inventory'); // Assuming Inventory Service runs on port 8080
    const data = await response.json();
    return data;
  }
};

app.use('/graphql', graphqlHTTP({
  schema: schema,
  rootValue: root,
  graphiql: true,
}));

app.get('/inventory', async (req, res) => {
    const response = await fetch('http://localhost:8080/inventory');
    const data = await response.json();
    res.json(data);
});

app.listen(port, () => {
  console.log(`BFF listening at http://localhost:${port}`);
});