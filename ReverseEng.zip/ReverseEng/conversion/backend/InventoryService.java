import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class InventoryService {

    private List<InventoryItem> items = new ArrayList<>();

    public InventoryService() {
        items.add(new InventoryItem(1, "Laptop", 10, 999.99));
        items.add(new InventoryItem(2, "Smartphone", 50, 699.99));
        items.add(new InventoryItem(3, "Tablet", 30, 499.99));
    }

    public List<InventoryItem> getItems() {
        return items;
    }

    public Optional<InventoryItem> getItemById(int itemId) {
        return items.stream().filter(item -> item.getItemId() == itemId).findFirst();
    }

    public void addItem(InventoryItem item) {
        items.add(item);
    }

    public void updateItem(InventoryItem item) {
        Optional<InventoryItem> existingItem = items.stream().filter(i -> i.getItemId() == item.getItemId()).findFirst();
        existingItem.ifPresent(i -> {
            i.setName(item.getName());
            i.setQuantity(item.getQuantity());
            i.setPrice(item.getPrice());
        });
    }
}
