import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/inventory")
public class InventoryController {

    @Autowired
    private InventoryService inventoryService;

    @GetMapping
    public List<InventoryItem> getAllItems() {
        return inventoryService.getItems();
    }

    @GetMapping("/{itemId}")
    public Optional<InventoryItem> getItemById(@PathVariable int itemId) {
        return inventoryService.getItemById(itemId);
    }

    @PostMapping
    public void addItem(@RequestBody InventoryItem item) {
        inventoryService.addItem(item);
    }

    @PutMapping
    public void updateItem(@RequestBody InventoryItem item) {
        inventoryService.updateItem(item);
    }
}