CREATE TABLE Inventory (
    ItemId INT PRIMARY KEY,
    Name VARCHAR(255),
    Quantity INT,
    Price DECIMAL(10, 2)
);