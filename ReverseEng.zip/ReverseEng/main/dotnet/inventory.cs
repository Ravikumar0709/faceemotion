using System;
using System.Collections.Generic;

public class InventoryItem
{
    public int ItemId { get; set; }
    public string Name { get; set; }
    public int Quantity { get; set; }
    public decimal Price { get; set; }
}

public class InventoryService
{
    private List<InventoryItem> items = new List<InventoryItem>();

    public InventoryService()
    {
        items.Add(new InventoryItem { ItemId = 1, Name = "Laptop", Quantity = 10, Price = 999.99m });
        items.Add(new InventoryItem { ItemId = 2, Name = "Smartphone", Quantity = 50, Price = 699.99m });
        items.Add(new InventoryItem { ItemId = 3, Name = "Tablet", Quantity = 30, Price = 499.99m });
    }

    public List<InventoryItem> GetItems()
    {
        return items;
    }

    public InventoryItem GetItemById(int itemId)
    {
        return items.Find(item => item.ItemId == itemId);
    }

    public void AddItem(InventoryItem item)
    {
        items.Add(item);
    }

    public void UpdateItem(InventoryItem item)
    {
        var existingItem = items.Find(i => i.ItemId == item.ItemId);
        if (existingItem != null)
        {
            existingItem.Name = item.Name;
            existingItem.Quantity = item.Quantity;
            existingItem.Price = item.Price;
        }
    }
}
