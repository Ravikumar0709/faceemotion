import os
import json
import logging
import streamlit as st
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI
import asyncio
import nest_asyncio

# Load API key
load_dotenv()
os.environ["GOOGLE_API_KEY"] = os.getenv("GOOGLE_API_KEY")

# Apply nest_asyncio to allow nested event loops in Streamlit
nest_asyncio.apply()

# Initialize Gemini model
llm = ChatGoogleGenerativeAI(model='gemini-2.0-flash', temperature=0.2)

# Create folders for saving converted code
def setup_conversion_folders(base_path="conversion"):
    os.makedirs(base_path, exist_ok=True)
    sections = ["backend", "frontend", "bff", "graphql", "database"]
    paths = {}
    for section in sections:
        path = os.path.join(base_path, section)
        os.makedirs(path, exist_ok=True)
        paths[section] = path
    return paths

# Collect .aspx, .cs, and .sql files from the repo
def traverse_repo(root_dir):
    file_data = {"asp": [], "dotnet": [], "database": []}
    for root, _, files in os.walk(root_dir):
        for file in files:
            file_path = os.path.join(root, file)
            try:
                if file.endswith(".aspx"):
                    with open(file_path, "r", encoding='utf-8', errors='ignore') as f:
                        file_data["asp"].append(f.read())
                elif file.endswith(".cs"):
                    with open(file_path, "r", encoding='utf-8', errors='ignore') as f:
                        file_data["dotnet"].append(f.read())
                elif file.endswith(".sql"):
                    with open(file_path, "r", encoding='utf-8', errors='ignore') as f:
                        file_data["database"].append(f.read())
            except Exception as e:
                logging.warning(f"Error reading {file_path}: {e}")
    return file_data

# Async AI conversion function
async def analyze_and_convert_code(file_data):
    code_combined = "\n".join(file_data["asp"] + file_data["dotnet"] + file_data["database"])

    prompt = f"""
You are a software transformation assistant.

Below is monolithic legacy code (ASP.NET, .NET, SQL). Convert it to a microservices-based architecture:

- Convert ASP.NET frontend to Micro Frontend Framework (JS).
- Convert .NET backend to Java Spring Boot microservices.
- Create a BFF using Node.js or Java.
- Migrate SQL to DynamoDB (or keep as SQL where logical).
- Use GraphQL for data access.

Respond ONLY with a raw JSON like:

{{
  "backend": [{{"filename": "UserService.java", "content": "class UserService {{ ... }}"}}],
  "frontend": [{{"filename": "LoginComponent.js", "content": "function Login() {{ ... }}"}}],
  "bff": [{{"filename": "bff.js", "content": "..."}}],
  "graphql": [{{"filename": "schema.graphql", "content": "type Query {{ ... }}"}}],
  "database": [{{"filename": "create_users_table.sql", "content": "CREATE TABLE ..." }}]
}}

Do not wrap it in markdown (no ```json).
Here is the code:
{code_combined}
"""
    try:
        response = await llm.ainvoke(prompt)
        return response.content
    except Exception as e:
        st.error(f"❌ Error during AI generation: {e}")
        return None

# Save each code snippet to its respective folder
def save_converted_code(json_data, folders):
    if json_data is None:
        return False, "❌ No JSON data to save due to an error during AI generation."
    try:
        cleaned_json = json_data.strip()

        if cleaned_json.startswith("```json"):
            cleaned_json = cleaned_json.replace("```json", "").replace("```", "").strip()

        parsed = json.loads(cleaned_json)

        for section, files in parsed.items():
            if section in folders:
                for file in files:
                    filename = file.get("filename", "unknown")
                    content = file.get("content", "")

                    # Add extension if missing based on section
                    if '.' not in filename:
                        ext_map = {
                            "backend": ".java",
                            "frontend": ".js",
                            "bff": ".js",
                            "graphql": ".graphql",
                            "database": ".sql"
                        }
                        filename += ext_map.get(section, ".txt")

                    filename = filename.replace(" ", "_")  # clean filename
                    file_path = os.path.join(folders[section], filename)

                    with open(file_path, "w", encoding="utf-8") as f:
                        f.write(content)

        return True, "✅ All converted files saved successfully in the 'conversion/' folder."
    except json.JSONDecodeError as e:
        logging.error(f"Failed to decode JSON. Raw output: {json_data[:500]}")
        return False, f"❌ Error decoding AI output as JSON: {e}"
    except Exception as e:
        logging.error(f"Failed to parse or save files. Raw output: {json_data[:500]}")
        return False, f"❌ Error saving files: {e}"

# ------------------------- Streamlit UI -------------------------

st.set_page_config(page_title="Legacy to Microservices Converter", layout="wide")
st.title("🛠️ AI Legacy Code Converter")
st.markdown("Automatically convert ASP.NET / .NET / SQL monolith to a modern Microservices architecture using Generative AI (Google Gemini).")

root_dir = st.text_input("📁 Enter the path to your code repository:")

if st.button("🚀 Convert Now"):
    if root_dir and os.path.isdir(root_dir):
        st.info("🔍 Scanning your repository...")
        file_data = traverse_repo(root_dir)

        st.success(f"✅ Found {len(file_data['asp'])} ASP.NET files")
        st.success(f"✅ Found {len(file_data['dotnet'])} .NET files")
        st.success(f"✅ Found {len(file_data['database'])} SQL files")

        st.info("⚙️ Sending code to AI for conversion...")
        loop = asyncio.get_event_loop()
        converted_json = loop.run_until_complete(analyze_and_convert_code(file_data))

        if converted_json:
            st.subheader("🧪 Raw AI Output (for debugging)")
            st.code(converted_json, language="json")

            st.info("📁 Saving files into appropriate folders...")
            folders = setup_conversion_folders()
            success, msg = save_converted_code(converted_json, folders)

            if success:
                st.success(msg)
            else:
                st.error(msg)
                st.text_area("⚠️ Raw Output (check for issues):", converted_json, height=300)
        else:
            st.warning("⚠️ AI conversion failed. Check the error messages above.")
    else:
        st.error("❌ Please enter a valid folder path.")
